This addon complements the tools for working with GeometryNodes.

This version of the addon includes.
1. General
    1) Hide all group input nodes unused sockets.
2. NamedAttribute
    1) Find and show by name
    2) Rename
3. GroupInput
    1) Find all group input node used sockets and show.
    2) Copy input sockets and paste to another



![Nodehelper1](https://github.com/user-attachments/assets/9ee18478-ca78-4498-9445-5cbb80e7e187)
